package com.pavi.assignments.springcoreAssignments;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt=new ClassPathXmlApplicationContext("com/pavi/assignments/springcoreAssignments/config.xml");
		ShoppingCart cart = (ShoppingCart) cxt.getBean("shoppingcart");
		System.out.println(cart);
	}

}
