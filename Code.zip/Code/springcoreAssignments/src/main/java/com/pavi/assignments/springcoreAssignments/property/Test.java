package com.pavi.assignments.springcoreAssignments.property;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt=new ClassPathXmlApplicationContext("com/pavi/assignments/springcoreAssignments/property/config.xml");
		wsClient client = (wsClient) cxt.getBean("wsclient");
		System.out.println(client);
	}

}
