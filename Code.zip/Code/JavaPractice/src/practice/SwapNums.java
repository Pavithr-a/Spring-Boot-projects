package practice;

public class SwapNums {

	public static void main(String[] args) {

		int a=23,b=43;
		
		System.out.println("Before swapping :"+a+"  "+b);
		
		b=a+b;
		a=b-a;
		b=b-a;
		
		System.out.println("After swapping: "+a+" "+b);
	}

}
