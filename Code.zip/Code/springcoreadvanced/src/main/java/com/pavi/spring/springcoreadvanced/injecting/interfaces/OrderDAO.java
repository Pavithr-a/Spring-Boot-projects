package com.pavi.spring.springcoreadvanced.injecting.interfaces;

public interface OrderDAO {
	
	void createOrder();

}
