package studentdatabaseapp;

import java.util.Scanner;

public class Student {

	private String firstName;
	private String lastName;
	private String gradeYear;
	private String studentID;
	private String courses = null;
	private String balance;
	private int tuitionBalance;
	private static int costOfCourse = 600;
	private static int id = 1000;

	// constructor: student's name and yr
	public Student() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
		this.firstName = sc.nextLine();

		System.out.println("Enter Last Name: ");
		this.lastName = sc.nextLine();

		System.out.println("\n1.Freshmen \n2.Sophomore \n3.Junior\n4.Senior \nEnter student class level: ");
		this.gradeYear = sc.nextLine();

		setStudentID();
		// System.out.println(firstName + " " + lastName + " " + gradeYear + " " +
		// studentID);

	}

	// generate ID
	private void setStudentID() {
		// grade level+ID
		id++;
		this.studentID = gradeYear + "" + id;

	}

	// enroll in courses
	public void enroll() {
		// inside a loop,user hits 0
		do {
			System.out.print("Enter course to enroll (Q to quit) :");
			Scanner sc = new Scanner(System.in);
			String course = sc.nextLine();
			if (!course.equals("Q")) {
				courses += "\n  " + course;
				tuitionBalance += costOfCourse;
			} else {
				// System.out.println("Break!");
				break;
			}
		} while (1 != 0);
		// System.out.println("ENROLLED IN :" + courses);
		// System.out.println("TUITION BALANCE: " + tuitionBalance);

	}

	// view balance
	public void viewBalance() {
		System.out.println("Your balance is: $" + tuitionBalance);
	}

	// pay tuition
	public void payTuition() {
		viewBalance();
		System.out.print("Enter your payment: $");
		Scanner sc = new Scanner(System.in);
		int payment = sc.nextInt();
		tuitionBalance -= payment;
		System.out.println("Thank you for your payment $" + payment);
		viewBalance();
	}

	// show status
	public String toString() {
		return "Name : " + firstName + " " + lastName + "\nGrade Level: " + gradeYear +"\nStudentId: "+studentID+ "\nCourses enrolled: " + courses
				+ "\nBalance: $" + tuitionBalance;
	}

}
