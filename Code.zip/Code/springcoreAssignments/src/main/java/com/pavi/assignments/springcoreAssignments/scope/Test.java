package com.pavi.assignments.springcoreAssignments.scope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext(
				"com/pavi/assignments/springcoreAssignments/scope/config.xml");

		University university = (University) cxt.getBean("university");
		System.out.println(university.hashCode());

		University university2 = (University) cxt.getBean("university");
		System.out.println(university2.hashCode());
	}

}
