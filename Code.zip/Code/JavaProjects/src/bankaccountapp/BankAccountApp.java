package bankaccountapp;

import java.util.LinkedList;
import java.util.List;

public class BankAccountApp {

	public static void main(String[] args) {
		List<Account> accounts=new LinkedList<Account>();
		
		
		String file="D:\\dev-spring-boot\\NewAccountHolders.csv";
		
		/*Checking chkacc1=new Checking("Tom Holland","546258321",2000);
		Savings savacc1=new Savings("Rich Lowe","554762125",5400);
		savacc1.showInfo();
		chkacc1.showInfo();
		
*/		

		//Read a CSV file then create new accounts based on that data
		List<String[]> newCustomers=utilities.CSV.read(file);
		
		for(String[] accHolders:newCustomers) {
			//System.out.println("NEW ACCOUNT");
			String name=accHolders[0];
			String sSN=accHolders[1];
			String accountType=accHolders[2];
			double initDeposit=Double.parseDouble(accHolders[3]);
			//System.out.println(name+" "+sSN+" "+accountType+" $"+initDeposit);
			if(accountType.equals("Savings")) {
				//System.out.println("OPEN SAVINGS ACC");
				accounts.add(new Savings(name, sSN, initDeposit));
			}else if(accountType.equals("Checking")) {
				//System.out.println("OPEN CHECKING ACC");
				accounts.add(new Checking(name, sSN, initDeposit));
			}else {
				System.out.println("ERROR READING ACCOUNT TYPE");
			}	
		}
		
		//accounts.get(1).showInfo();
		
		for(Account acc:accounts) {
			System.out.println("\n************");
			acc.showInfo();
		}
		
		//accounts.get((int) Math.random() * accounts.size()).deposit(10000);
		//accounts.get((int) Math.random() * accounts.size()).deposit(1500); 
		
	}

}
