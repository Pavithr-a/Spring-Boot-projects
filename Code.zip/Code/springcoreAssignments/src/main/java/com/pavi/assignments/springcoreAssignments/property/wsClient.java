package com.pavi.assignments.springcoreAssignments.property;

public class wsClient {
	private String dbServer,userName,password, url;
	
	public wsClient(String dbServer,String url,String userName,String password) {
		this.dbServer=dbServer;
		this.url=url;
		this.userName=userName;
		this.password=password;
	}

	@Override
	public String toString() {
		return "wsClient [dbServer=" + dbServer + ", userName=" + userName + ", password=" + password + ", url=" + url
				+ "]";
	}


	
	

}
