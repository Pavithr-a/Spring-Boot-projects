package com.pavi.assignments.springcoreAssignments.jdbc.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pavi.assignments.springcoreAssignments.jdbc.dao.PassengerDao;
import com.pavi.assignments.springcoreAssignments.jdbc.entity.Passenger;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext(
				"com/pavi/assignments/springcoreAssignments/jdbc/test/config.xml");
		PassengerDao dao = (PassengerDao) cxt.getBean("passengerDao");
		//Passenger passenger=new Passenger();
		/*passenger.setId(4);
		passenger.setFirstName("Rajini");
		passenger.setLastName("Kanth");*/
		//int result = dao.create(passenger);
		//int result=dao.update(passenger);
		//int result=dao.delete(4);
		//Passenger passenger=dao.read(3);
		List<Passenger> result=dao.read();
		System.out.println("Passengers records:"+result);
	}

}
