package com.pavi.assignments.springcoreAssignments.lifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
	AbstractApplicationContext cxt=new ClassPathXmlApplicationContext("com/pavi/assignments/springcoreAssignments/lifecycle/config.xml");
	TicketReservation ticket=(TicketReservation) cxt.getBean("ticket");
	System.out.println(ticket);
	cxt.registerShutdownHook();
	}
}
