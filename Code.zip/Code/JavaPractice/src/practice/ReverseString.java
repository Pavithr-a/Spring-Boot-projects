package practice;

public class ReverseString {
	
	public static void main(String[] args) {
		
	String str="Welcomee",nstr="";
	char ch;
	
	System.out.println("Original string is:"+str);
	
	for(int i=0;i<str.length();i++) {
		ch=str.charAt(i);
		nstr=ch+nstr;
	}
	System.out.println("Reversed String is: "+nstr);
	}
}
