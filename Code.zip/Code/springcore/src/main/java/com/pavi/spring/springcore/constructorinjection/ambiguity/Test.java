package com.pavi.spring.springcore.constructorinjection.ambiguity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt=new ClassPathXmlApplicationContext("com/pavi/spring/springcore/constructorinjection/ambiguity/config.xml");
		Addition add =  (Addition) cxt.getBean("addition");
		System.out.println(add);
	}

}
