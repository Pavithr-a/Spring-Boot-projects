package com.luv2code.servletdemo.mvctwo;

import java.util.ArrayList;
import java.util.List;

public class StudentDataUtil {
	public static List<Student> getStudents(){
		
		//create an empty list
		List<Student> students=new ArrayList<>();
		
		//add sample data
		students.add(new Student("Mary", "Public", "mary@luv2code.com"));
		students.add(new Student("John","Wick","john@luv2code.com"));
		students.add(new Student("Will","Smith","will@luv2code.com"));
		students.add(new Student("Rock","Dwayne","dwayne@luv2code.com"));
		
		
		//return the list
		return students;
		
	}

}
