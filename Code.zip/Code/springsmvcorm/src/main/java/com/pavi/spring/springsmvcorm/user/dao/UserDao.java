package com.pavi.spring.springsmvcorm.user.dao;

import com.pavi.spring.springsmvcorm.user.entity.User;

public interface UserDao {
	
	int create(User user);

}
