package com.pavi.spring.springcore.dependencycheck;

import java.util.List;

import org.springframework.beans.factory.annotation.Required;

public class Prescription {
	
	private int id;
	private String PatientName;
	private List<String> medicines;

	public int getId() {
		return id;
	}
	
	@Required
	public void setId(int id) {
		this.id = id;
	}

	public String getPatientName() {
		return PatientName;
	}

	@Required
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public List<String> getMedicines() {
		return medicines;
	}

	@Required
	public void setMedicines(List<String> medicines) {
		this.medicines = medicines;
	}

	@Override
	public String toString() {
		return "Prescription [id=" + id + ", PatientName=" + PatientName + ", medicines=" + medicines + "]";
	}

}
