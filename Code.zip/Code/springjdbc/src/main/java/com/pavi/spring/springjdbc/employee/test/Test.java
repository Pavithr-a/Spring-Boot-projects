package com.pavi.spring.springjdbc.employee.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.pavi.spring.springjdbc.employee.dao.EmployeeDao;
import com.pavi.spring.springjdbc.employee.entity.Employee;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext(
				"com/pavi/spring/springjdbc/employee/test/config.xml");
		EmployeeDao dao = (EmployeeDao) cxt.getBean("employeeDao");
		/*Employee employee = new Employee();
		employee.setId(4);
		employee.setFirstName("Sabari");
		employee.setLastName("Nagu");
		 int result = dao.create(employee);*/   //create
		// int result=dao.update(employee);     //update
		// int result=dao.delete(1);			//delete
		// Employee employee = dao.read(2);		//read single query
		List<Employee> result = dao.read();	//read multiple queries
		System.out.println("Employee record: " +result);
	}

}
