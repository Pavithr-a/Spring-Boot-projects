package practice;

import java.util.Scanner;

public class Vowels {
	//can be done in 2ways
	
	//method 1
	/*public static void main(String[] args) {
		System.out.println(stringContainsVowels("tv"));
		System.out.println(stringContainsVowels("Welcome"));
	}

	public static boolean stringContainsVowels(String input) {
		return input.matches(".*[aeiou].*");
		
	}*/
	
	//method 2
	public static void main(String[] args) {
		String let;
		System.out.println("Type word:");
		Scanner sc=new Scanner(System.in);
		let=sc.nextLine();
		
		System.out.println(let.matches(".*[aeiou].*"));
	}
}
