package com.pavi.assignments.springcoreAssignments.orm.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pavi.assignments.springcoreAssignments.orm.dao.PassengerDao;
import com.pavi.assignments.springcoreAssignments.orm.entity.Passenger;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext(
				"com/pavi/assignments/springcoreAssignments/orm/test/config.xml");
		PassengerDao passengerDao = (PassengerDao) cxt.getBean("passengerDao");
		/*Passenger passenger=new Passenger();
		passenger.setId(3);
		passenger.setFirstName("Arjit");
		passenger.setLastName("Singh");
		passengerDao.create(passenger);*/
		//passengerDao.update(passenger);
		//passengerDao.delete(passenger);
		//Passenger passenger = passengerDao.find(3);
		//System.out.println(passenger);
		List<Passenger> passengers = passengerDao.findAll();
		System.out.println(passengers);
	}

}
