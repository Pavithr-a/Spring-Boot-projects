package com.pavi.spring.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Test {
	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("com/pavi/spring/springjdbc/config.xml");
		JdbcTemplate jdbcTemplate = (JdbcTemplate) cxt.getBean("jdbcTemplate");
		String sql = "insert into employee values(?,?,?)";
		int result = jdbcTemplate.update(sql, new Integer(1), "Pavi", "Senthil");
		System.out.println("Number of records inserted are: " + result);
	}

}
