package com.pavi.spring.springcore.constructorinjection.ambiguity;

public class Addition {
	
	
	/*public Addition(Double a,Double b) {
		System.out.println("Inside constructor DOUBLE");
	}

	public Addition(int a,int b) {
		System.out.println("Inside constructor INT");
	}
	
	public Addition(String a,String b) {
		System.out.println("Inside constructor String");
	}*/
	
	public Addition(int a,double b) {
		System.out.println("Inside constructor");
		System.out.println(a);
		System.out.println(b);
	}
	
}
