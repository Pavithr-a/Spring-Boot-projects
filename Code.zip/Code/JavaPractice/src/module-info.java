/**
 * 
 */
/**
 * @author Rithanya Senthil
 *
 */
module JavaPractice {
}