package com.pavi.spring.springcoreadvanced.injecting.interfaces;

public interface OrderBO {

	void placeOrder();
	
}
