package com.pavi.assignments.springcoreAssignments.jdbc.dao;

import java.util.List;

import com.pavi.assignments.springcoreAssignments.jdbc.entity.Passenger;

public interface PassengerDao {
	int create(Passenger passenger);
	
	int update(Passenger passenger);
	
	int delete(int id);
	
	Passenger read(int id);
	
	List<Passenger> read();

}
