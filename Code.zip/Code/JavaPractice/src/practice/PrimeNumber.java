package practice;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter num:");
		num=sc.nextInt();
		
		if(num==0||num==1) {
			System.out.println("Not a prime");
		}
		else if(num==2) {
			System.out.println("Prime");
		}
		else {
			
		for(int i=2;i<=num/2;i++) {
			if(num%i==1) {
				System.out.println("prime");
				break;
			}
			else {
				System.out.println("Not a prime");
				break;
			}
			
		}
		
		}
		
		
	}
}
